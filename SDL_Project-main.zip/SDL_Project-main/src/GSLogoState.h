#pragma once

#include "StructsDef.h"

void GSLogoStateUpdate(float delta, ResourceManager& resource);