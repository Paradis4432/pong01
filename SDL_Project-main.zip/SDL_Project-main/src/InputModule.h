#pragma once
#include "StructsDef.h"

void onKeyDown(int keyCode, InputState& input);
void onKeyUp(int keyCode, InputState& input);