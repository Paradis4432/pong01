
## Section 1
<a id="section-1"></a>

1.	Una vez que este instalado, abrilo que vas a ver una ventana parecida a la siguiente y  hacele click en Crear un Proyecto.
<img src="./img/project.png">
 
2.	Fijate en la siguiente ventana que aparece de seleccionar "Aplicación de consola"
<img src="./img/create.png">
 
3.	Y finalmente seleccionar la carpeta destino donde se guardaran los archivos y donde podras colocar el nombre del proyecto.
<img src="./img/setup.png">
 
4.	Listo ahi si podes escribir tu codigo!
<img src="./img/code.png">